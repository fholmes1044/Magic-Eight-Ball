# Magic Eight Ball

A Pen created on CodePen.io. Original URL: [https://codepen.io/faithhol/pen/qBxbGLL](https://codepen.io/faithhol/pen/qBxbGLL).

