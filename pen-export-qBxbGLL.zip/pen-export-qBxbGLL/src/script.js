var userName = '';
if (userName =='Jane') {console.log('Hello, Jane');}
else{console.log ('Hello');}

var userQuestion = 'What would you like to know';
console.log (userQuestion);

var randomNumber = Math.floor(Math.random() * 8);

var eightBall = randomNumber;

if (eightBall >= 0 && eightBall <=1) {console.log('It is certain');}
if (eightBall > 1 && eightBall <=2) {console.log('It is decidedly so');}
if (eightBall > 2 && eightBall <=3) {console.log('Reply hazy try again');}
if (eightBall > 3 && eightBall <=4) {console.log('Cannot predict now');}
if (eightBall > 4 && eightBall <=5) {console.log('Do not count on it');}
if (eightBall > 5 && eightBall <=6) {console.log('My sources say no');}
if (eightBall > 6 && eightBall <=7) {console.log('Outlook not so good');}
if (eightBall > 8 && eightBall <=9) {console.log('Signs point to yes');}
